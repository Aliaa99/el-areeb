<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>el-areeb</title>
    <link rel="stylesheet" href="css/fontawesome-all.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-rtl.min.css">
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/animate.min.css">
    <link rel="stylesheet" href="css/aos.css">
    <link rel="stylesheet" href="css/slick.css">
    <link rel="stylesheet" href="css/slick-theme.css">
    <link rel="stylesheet" href="fonts/stylesheet.css">
    <link rel="shortcut icon" href="images/logo.png">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<header>
<div class="uper-head">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-7 col-sm-8 col-xs-8">
                    <div class="select">
                        <div class="dropdown">
                            <button href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                            <img src="images\ar.png" alt="" class="choose-lang-img"><span>اللغة</span>
                            <span class="caret"></span></button>
                            <ul class="dropdown-menu lang" style="display: none;">
                                <li><a href="#"><img src="images\ar.png" alt="">عربى</a></li>
                                <li><a href="#"><img src="images\ar.png" alt="">english</a></li>
                            </ul>
                        </div>
                        <div class="dropdown">
                            <button href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fas fa-dollar-sign"></i>
                            <span>رأس العملة</span>
                            <span class="caret"></span></button>
                            <ul class="dropdown-menu lang">
                                <li> <a href="#"> دولار</a></li>
                                <li> <a href="#"> ريال</a></li>
                            </ul>
                        </div>
                        <div class="dropdown ">
                            <button href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="flaticon-user"></i>
                            <span>حسابى</span>
                            <span class="caret"></span></button>
                            <ul class="dropdown-menu lang" style="display: none;">
                                <li><a href="#">عربى</a></li>
                                <li><a href="#">english</a></li>
                            </ul>
                        </div>
                        <div class="dropdown ">
                            <a href="#"><i class="flaticon-like"></i><span>قائمة رغباتى</span>
                            <span >(0)</span></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-5 col-sm-4 col-xs-4">
                    <ul>
                        <li class="tel-mail"><a href="Tel:0109225785578" class="telephone"><span>011449899754659</span> <i class="flaticon-call-answer"></i></a></li>
                        <li class="tel-mail"><a href="mailto:email@example.com" class="mail"><i class="flaticon-envelope"></i><span>aliaa@bb4it.com</span> </a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>    
    <div class="logo-small">
        <a href="#"><img src="images/logo.png" alt=""></a>
        <a class="side-menu"><i class="fas fa-bars"></i></a>
           <div id="cart2" class="btn-group btn-block">
              <button type="button" data-toggle="dropdown" data-loading-text="جاري ..." class="btn btn-inverse btn-block btn-lg dropdown-toggle" aria-expanded="false"><i class="fa fa-shopping-cart"></i> <span id="cart-total">1 منتجات - مجانا</span></button>
              <ul class="dropdown-menu pull-right">
                    <li>
                  <table class="table table-striped">
                            <tbody><tr>
                      <td class="text-center">            
                      <a href="https://opencartarab.com/تعديل-توقيت-السيرفر"><img src="https://opencartarab.com/image/cache/catalog/timezone/timezone-47x47.jpg" alt="تعديل توقيت السيرفر" title="تعديل توقيت السيرفر" class="img-thumbnail"></a>
                        </td>
                      <td class="text-right"><a href="https://opencartarab.com/تعديل-توقيت-السيرفر">تعديل توقيت السيرفر</a>
                                    </td>
                      <td class="text-right">x 1</td>
                      <td class="text-right">مجانا</td>
                      <td class="text-center"><button type="button"  title="حذف" class="btn btn-danger btn-xs"><i class="fa fa-times"></i></button></td>
                    </tr>
                                  </tbody></table>
                </li>
                <li>
                  <div>
                    <table class="table table-bordered">
                                <tbody><tr>
                        <td class="text-right"><strong>الاجمالي</strong></td>
                        <td class="text-right">مجانا</td>
                      </tr>
                                <tr>
                        <td class="text-right"><strong>الاجمالي النهائي</strong></td>
                        <td class="text-right">مجانا</td>
                      </tr>
                              </tbody></table>
                    <p class="text-right"><a href="https://opencartarab.com/cart"><strong><i class="fa fa-shopping-cart"></i> معاينة السلة</strong></a>&nbsp;&nbsp;&nbsp;<a href="https://opencartarab.com/checkout"><strong><i class="fa fa-reply"></i> إنهاء الطلب</strong></a></p>
                  </div>
                </li>
            </ul>
        </div>
    </div>
    <div class="navbar">
            <!-- close link in side menu -->
                <a  class="close-link-menu"><i class="fas fa-times"></i></a>
        <div class="container">
            <div class="row">
                <div class="col-lg-2 col-md-2 col-sm-2">
                    <div class="logo">
                        <img src="images\logo.png" alt="">
                    </div>
                </div>
                <div class="col-lg-7 col-md-10 col-sm-10">
                    <ul class="nav mainlist">
                        <li>
                            <a href="#"class="listlink">الرئيسية </a>
                        </li>
                        <!--dropdown list mega-->
                        <li class="dropdown mega-dropdown">
                            <a href="#" class="dropdown-toggle listlink" data-toggle="dropdown"> الاطقم  <span class="caret"></span>  </a>
                            
                            <!--dropdowen mega menu-->
                            <ul class="dropdown-menu mega-dropdown-menu" style="display: none;">
            					<li class="col-sm-3">
            					    <ul>
                                        <li><a href="#">رجالى</a></li>
                                        <li><a href="#">نسائي</a></li>
                                        <li><a href="#">أطفال</a></li>
                                    </ul>
                    			</li>
            					<li class="col-sm-3">
            					    <ul>
                                        <li><a href="#">رجالى</a></li>
                                        <li><a href="#">نسائي</a></li>
                                        <li><a href="#">أطفال</a></li>
                                    </ul>
                    			</li>
            					<li class="col-sm-3">
            					    <ul>
                                        <li><a href="#">رجالى</a></li>
                                        <li><a href="#">نسائي</a></li>
                                        <li><a href="#">أطفال</a></li>
                                    </ul>
                    			</li>
            					<li class="col-sm-3">
            					    <ul>
                                        <li><a href="#">رجالى</a></li>
                                        <li><a href="#">نسائي</a></li>
                                        <li><a href="#">أطفال</a></li>
                                    </ul>
                    			</li>
                    			<li class="col-sm-12 pp">
                    			    <a href="#">عرض كل مشغلات ام بي سي</a>
                    			</li>
                            </ul>
                            
                        </li>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle listlink" data-toggle="dropdown">عقود وقلائد <span class="caret"></span> </a>
                            
                            <ul class="dropdown-menu lang fixed-menu smaldropdown" style="display: none;">
                                <li><a href="#">عربى</a></li>
                                <li><a href="#">english</a></li>
                                <li class="pp">
                    			    <a href="#">عرض كل مشغلات ام بي سي</a>
                    			</li>
                            </ul>
                        </li>
                        <li>
                            <a href="#" class="listlink">الاساور </a>
                        </li>
                        <li>
                            <a href="#" class="listlink">الخواتم </a>
                        </li>
                        <li>
                            <a href="#" class="listlink">اقراط الاذن </a>
                        </li>
                        <li>
                            <a href="#" class="listlink">دبل خطوبة </a>
                        </li>
                    </u>
                </div>
                <div class="col-lg-3 col-md-4 col-sm-4">
                    <div id="cart" class="btn-group btn-block ">
                          <button type="button" data-toggle="dropdown" data-loading-text="جاري ..." class="btn btn-inverse btn-block btn-lg dropdown-toggle" aria-expanded="true"><i class="fa fa-shopping-cart"></i> <span id="cart-total">1 منتجات - مجانا</span></button>
                          <ul class="dropdown-menu pull-right">
                                <li>
                              <table class="table table-striped">
                                        <tbody><tr>
                                  <td class="text-center">            <a href="https://opencartarab.com/تعديل-توقيت-السيرفر"><img src="https://opencartarab.com/image/cache/catalog/timezone/timezone-47x47.jpg" alt="تعديل توقيت السيرفر" title="تعديل توقيت السيرفر" class="img-thumbnail"></a>
                                    </td>
                                  <td class="text-right"><a href="https://opencartarab.com/تعديل-توقيت-السيرفر">تعديل توقيت السيرفر</a>
                                                </td>
                                  <td class="text-right">x 1</td>
                                  <td class="text-right">مجانا</td>
                                  <td class="text-center"><button type="button"  title="حذف" class="btn btn-danger btn-xs"><i class="fa fa-times"></i></button></td>
                                </tr>
                                              </tbody></table>
                            </li>
                            <li>
                              <div>
                                <table class="table table-bordered">
                                            <tbody><tr>
                                    <td class="text-right"><strong>الاجمالي</strong></td>
                                    <td class="text-right">مجانا</td>
                                  </tr>
                                            <tr>
                                    <td class="text-right"><strong>الاجمالي النهائي</strong></td>
                                    <td class="text-right">مجانا</td>
                                  </tr>
                                          </tbody></table>
                                <p class="text-right"><a href="https://opencartarab.com/cart"><strong><i class="fa fa-shopping-cart"></i> معاينة السلة</strong></a>&nbsp;&nbsp;&nbsp;<a href="https://opencartarab.com/checkout"><strong><i class="fa fa-reply"></i> إنهاء الطلب</strong></a></p>
                              </div>
                            </li>
                              </ul>
                        </div>
                </div>
            </div>
        </div>
    </div>
    
</header>
