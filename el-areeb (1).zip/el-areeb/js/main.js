$(document).ready(function(){
    $('.center').slick({
        centerMode: true,
        centerPadding: '0px',
        slidesToShow: 2,
        slidesToScroll: 1,
        autoplay: true,
        vertical:true,
        autoplaySpeed: 2000,
      });
      

    $('.slide1').owlCarousel({
        loop:true,
        margin:10,
        nav:true,
        rtl:true,
        dots:false,
        navText:["",""],
        autoplay:true,
        autoplayTimeout:5000,
        responsive:{
            0:{
                items:1
            }
        }
    })
        
    // $('.slide2').owlCarousel({
    //     loop:true,
    //     margin:10,
    //     nav:false,
    //     rtl:true,
    //     dots:false,
    //     navText:["",""],
    //     autoplay:true,
    //     autoplayTimeout:5000,
    //     responsive:{
    //         0:{
    //             items:1
    //         },
    //         400:{
    //             items:2
    //         },
    //         767:{
    //             items:3
    //         },
    //         991:{
    //             items:5
    //         }
    //     }
    // })
        
   
    $('.company-logos').owlCarousel({
        loop:true,
        margin:10,
        nav:false,
        rtl:true,
        dots:false,
        navText:["",""],
        autoplay:true,
        autoplayTimeout:5000,
        responsive:{
            0:{
                items:1
            },
            400:{
                items:2
            },
            767:{
                items:3
            },
            991:{
                items:4
            }
        }
    })
    $('.buylink').click(function(){
        $('.product-table').toggle(300);
    })
    
    


    $(".dropdown").hover(
        function() {
            $('.dropdown-menu', this).not('.in .dropdown-menu').stop(true,true).slideDown("400");
            $(this).toggleClass('open');
        },
        function() {
            $('.dropdown-menu', this).not('.in .dropdown-menu').stop(true,true).slideUp("400");
            $(this).toggleClass('open');
        }
    );
    
 $('.fa-window-close').click(function(){
     $(this).parent().parent().parent().css("display","none");
 });
 
$('.heart i').click(function(){
    $(this).css("color","red");
    $(this).parent().parent().css("display","block");
});
    
$('.side-menu ,.close-link-menu').click(function(){
    $('.navbar').animate({
        width: "toggle"
      },1000);
  
});

$('[data-toggle="tooltip"]').tooltip(200);   

AOS.init({
    offset: 100,
    duration: 500,
    easing: 'ease-in-quad',
    delay: 0,
  });
  


$(window).scroll(function() {
    var scrollVal = $(this).scrollTop();
 if ( scrollVal > 50) {
     
     $('.logo-small').css({'background-color':'#eee','position':'fixed'});
 }
   else{
       
     $('.logo-small').css({'background-color':'transparent','position':'relative'});
   }
 
});

$(".btn-group .btn").click(function(){
    var inputValue = $(this).find("input").val();
    if(inputValue != 'all'){
        var target = $('.slide2 .col-lg-2[data-status="' + inputValue + '"]');
        $(".slide2 .col-lg-2").not(target).hide();
        target.fadeIn();
    } else {
        $(".slide2 .col-lg-2").fadeIn();
    }
});
// Changing the class of status label to support Bootstrap 4
var bs = $.fn.tooltip.Constructor.VERSION;
var str = bs.split(".");
if(str[0] == 4){
    $(".label").each(function(){
        var classStr = $(this).attr("class");
        var newClassStr = classStr.replace(/label/g, "badge");
        $(this).removeAttr("class").addClass(newClassStr);
    });
}





});





